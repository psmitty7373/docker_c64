'use strict';

const bodyParser = require('body-parser');
const browserify = require('browserify-middleware');
const express = require('express');
const {
    readdirSync,
    statSync
} = require('fs');
const {
    join
} = require('path');

const WebRtcConnectionManager = require('./lib/server/connections/webrtcconnectionmanager');
const RTCAudioSourceSineWave = require('./lib.js');

const app = express();

app.use(bodyParser.json());

function beforeOffer(peerConnection) {
    const source = new RTCAudioSourceSineWave();
    const track = source.createTrack();
    peerConnection.addTrack(track);

    function onMessage({
        data
    }) {
        console.log(data);
    }

    const {
        close
    } = peerConnection;
    peerConnection.close = function() {
        track.stop();
        source.close();
        return close.apply(this, arguments);
    };
}

const connectionManager = WebRtcConnectionManager.create({
    beforeOffer
});

app.get('/connections', (req, res) => {
    res.send(connectionManager.getConnections());
});

app.post('/connections', async (req, res) => {
    try {
        const connection = await connectionManager.createConnection();
        res.send(connection);
    } catch (error) {
        console.error(error);
        res.sendStatus(500);
    }
});

app.delete('/connections/:id', (req, res) => {
    const {
        id
    } = req.params;
    const connection = connectionManager.getConnection(id);
    if (!connection) {
        res.sendStatus(404);
        return;
    }
    connection.close();
    res.send(connection);
});

app.get('/connections/:id', (req, res) => {
    const {
        id
    } = req.params;
    const connection = connectionManager.getConnection(id);
    if (!connection) {
        res.sendStatus(404);
        return;
    }
    res.send(connection);
});

app.get('/connections/:id/local-description', (req, res) => {
    const {
        id
    } = req.params;
    const connection = connectionManager.getConnection(id);
    if (!connection) {
        res.sendStatus(404);
        return;
    }
    res.send(connection.toJSON().localDescription);
});

app.get('/connections/:id/remote-description', (req, res) => {
    const {
        id
    } = req.params;
    const connection = connectionManager.getConnection(id);
    if (!connection) {
        res.sendStatus(404);
        return;
    }
    res.send(connection.toJSON().remoteDescription);
});

app.post('/connections/:id/remote-description', async (req, res) => {
    const {
        id
    } = req.params;
    const connection = connectionManager.getConnection(id);
    if (!connection) {
        res.sendStatus(404);
        return;
    }
    try {
        await connection.applyAnswer(req.body);
        res.send(connection.toJSON().remoteDescription);
    } catch (error) {
        res.sendStatus(400);
    }
});

app.use('/blah.js', browserify('public/client.js'));
app.use(express.static('public'));
app.get('/index.html', (req, res) => {
    res.sendFile(join(__dirname, 'public', 'index.html'));
});

const server = app.listen(3000, () => {
    const address = server.address();
    console.log('Listening on port 3000.');
    server.once('close', () => {
        //connectionManagers.forEach(connectionManager => connectionManager.close());
    });
});